MrsS. Suits Store — Hostinger Node.js deployment
================================================

This folder is a complete production build. It does not require Replit,
Vite, React, pnpm, or any npm dependency to run.

Hostinger setup
---------------
1. Upload the contents of this folder to the Node.js application directory
   selected in Hostinger.
2. Set the Node.js version to 18 or newer.
3. Set the application start file to: server.js
4. Set the application port using Hostinger's Node.js application settings.
   The server reads the PORT environment variable automatically.
5. Start or restart the Node.js application.
6. Point your domain to the Hostinger Node.js application according to
   Hostinger's domain/proxy instructions.

Local test (optional)
---------------------
  PORT=3000 node server.js
Then open http://localhost:3000 in a browser.

Important
---------
- Keep the public assets and server.js in the same directory.
- The server includes SPA fallback routing so direct visits to website paths
  continue to work.
- This build uses the editorial demo imagery currently in the project. Replace
  files under images/ with the client's approved photos if desired, keeping the
  same filenames and image formats.
